m = mobiledev
m.Logging = true
