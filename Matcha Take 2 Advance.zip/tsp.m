m = mobiledev;
m.Logging = 1;
t0 = datetime;