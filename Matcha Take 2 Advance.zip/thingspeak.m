chID = 998255;
[log, Timestamps] = accellog(m);

while true
    response = thingSpeakWrite(chID, log, 'WriteKey', 'KF1LCOXFRLPO2HAK');
    pause(5);
end